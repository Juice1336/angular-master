class ExternalServiceImmediatelyCreated {}

class ExternalServiceLazilyCreatedMaybe {}
